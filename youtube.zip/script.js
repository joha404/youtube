// const hamBurger = document.querySelector(".toggle-btn");

// hamBurger.addEventListener("click", function () {
//   document.querySelector("#sidebar").classList.toggle("expand");
// });

const tab = document.querySelector(".tabs");
badges = tab.querySelectorAll(".tab");
(icons = document.querySelectorAll(".icon span")),
  ({ clienWidth, ScrollWidth } = tab);
badges.forEach((badge) => {
  badge.addEventListener("click", () => {
    tab.querySelector(".active").classList.remove("active");
    badge.classList.add("active");
    badge.scrollIntoView({
      inline: "cent",
    });
  });
});
tab.addEventListener("scroll", (e) => {
  updateIcons(e.target.scrollLeft);
});
function updateIcons(scrolled_width) {
  icons[0].parentElement.classList.toggle("hide", scrolled_width <= 1);
  icons[1].parentElement.classList.toggle(
    "hide",
    scrolled_width - (clienWidth + scrolled_width) <= 1
  );
}
